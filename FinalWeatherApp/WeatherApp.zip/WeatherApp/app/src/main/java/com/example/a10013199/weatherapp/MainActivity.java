package com.example.a10013199.weatherapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {
        public static final String API_KEY = "bc3a34cbe27843274a886b3e6619ec81";
    public static final String URL_PREFIX = "http://api.openweathermap.org/data/2.5/forecast?";
    public static final String URL_SUFFIX = "APPID=";

    URL urlTag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       try{
           urlTag = new URL(URL_PREFIX + "08852" + URL_SUFFIX + API_KEY);
           URLConnection urlConnection = urlTag.openConnection();
       } catch (Exception e){
           Log.d("TAG", e.toString());
       }

        InputStream inputStream = new InputStream() {
            @Override
            public int read() throws IOException {
                return 0;
            }
        };

    }
}
